# BRIAN MARKET

Starter project toko digital dengan branding sendiri, dibuat memakai HTML, CSS, dan JavaScript vanilla. Proyek ini memuat storefront responsif dan dokumentasi rancangan backend. **Backend, login, database, dan pembayaran belum aktif.**

## Struktur

```text
brian-market/
├── index.html
├── styles.css
├── app.js
├── README.md
└── backend/
    ├── README.md
    ├── schema.sql
    └── .env.example
```

## Jalankan secara lokal

1. Ekstrak `brian-market.zip`.
2. Buka `index.html` di browser, atau jalankan server lokal:
   ```bash
   python -m http.server 8000
   ```
3. Kunjungi `http://localhost:8000`.

Tidak ada build step atau dependensi npm untuk storefront demo.

## Fitur frontend

- Layout responsif desktop/mobile.
- Katalog contoh: Akun, Voucher, Tools, Kreatif.
- Pencarian, filter kategori, pengurutan.
- Detail produk, keranjang, jumlah item, subtotal.
- Riwayat pesanan demo tersimpan pada localStorage browser.
- Tombol WhatsApp terhubung ke nomor `6285166650775` dengan ringkasan pesan.
- Status demo ditampilkan supaya tidak disalahartikan sebagai transaksi nyata.

## Kustomisasi

- Produk: edit array `products` di `app.js`.
- WhatsApp admin: ubah `ADMIN_WHATSAPP` di `app.js`.
- Warna dan layout: edit variabel di awal `styles.css`.

## Deployment frontend ke Vercel

### Cara cepat
1. Unggah folder proyek ke repositori GitHub milikmu.
2. Masuk ke Vercel dan pilih **Add New → Project**.
3. Impor repositori tersebut.
4. Untuk static site ini, gunakan framework preset **Other** dan biarkan Build Command kosong. Output/static directory gunakan root proyek.
5. Deploy. Setelah itu uji link produksi di desktop dan HP.

Alternatif: Vercel CLI dari folder proyek (perlu Node.js dan akun Vercel):
```bash
npx vercel
```
Ikuti prompt CLI dan lakukan deployment produksi dengan:
```bash
npx vercel --prod
```

## Rancangan backend

Folder `backend/` memuat skema SQL awal untuk Supabase/PostgreSQL. Skema itu belum dijalankan dan bukan backend aktif. Ikuti `backend/README.md` sebelum menghubungkan frontend.

Sebelum menerima transaksi nyata, implementasikan:
- Autentikasi server-side yang aman dan kebijakan akses/RLS.
- Validasi harga, stok, kuantitas, dan total di server (jangan percaya total dari browser).
- Pembuatan pesanan melalui endpoint server.
- Integrasi payment gateway resmi menggunakan secret key di server/Edge Function.
- Verifikasi webhook pembayaran menggunakan signature dan idempotency.
- Pengiriman produk/aktivasi akun yang sah dan sesuai ketentuan penyedia.
- Kebijakan privasi, syarat layanan, penanganan refund, dan perlindungan data pelanggan.

Jangan menyimpan secret key payment gateway atau service-role key Supabase dalam JavaScript browser atau repository publik.

## Batasan versi saat ini

- Tidak ada login sungguhan.
- Tidak ada database yang terhubung.
- Riwayat dan keranjang hanya tersimpan di localStorage perangkat/browser.
- Tidak ada pembayaran yang diproses.
- Catatan pesanan demo bukan bukti transaksi.
- Harga, stok, dan katalog adalah contoh.
