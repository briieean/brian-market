/* BRIAN MARKET storefront demo.
 * Cart and demo order history use this browser's localStorage only.
 * No authentication, database, or payment provider is connected.
 */
const ADMIN_WHATSAPP = "6285166650775"; // Provided admin number; change if needed.
const products=[
{id:"bm001",name:"Premium Streaming",category:"Akun",price:25000,oldPrice:35000,badge:"POPULER",description:"Contoh produk hiburan digital untuk kebutuhan sehari-hari.",tone:"tone-purple",symbol:"▶",featured:1},
{id:"bm002",name:"Creative Design Pack",category:"Kreatif",price:18000,description:"Contoh aset digital untuk proyek kreatif.",tone:"tone-blue",symbol:"✳",featured:2},
{id:"bm003",name:"Game Voucher",category:"Voucher",price:50000,description:"Contoh voucher game; nominal dan ketentuan perlu dikonfirmasi.",tone:"tone-peach",symbol:"◆",featured:3},
{id:"bm004",name:"Productivity Tools",category:"Tools",price:32000,description:"Contoh perangkat bantu untuk alur kerja digital.",tone:"tone-mint",symbol:"⌘",featured:4},
{id:"bm005",name:"Music Access",category:"Akun",price:15000,description:"Contoh layanan hiburan audio digital.",tone:"tone-dark",symbol:"♫",featured:5},
{id:"bm006",name:"Social Media Kit",category:"Kreatif",price:22000,description:"Template contoh untuk konten media sosial.",tone:"tone-pink",symbol:"◎",featured:6},
{id:"bm007",name:"Digital Gift Card",category:"Voucher",price:75000,description:"Contoh kartu hadiah digital; bukan voucher aktif.",tone:"tone-yellow",symbol:"✧",featured:7},
{id:"bm008",name:"Cloud Storage Plan",category:"Tools",price:40000,description:"Contoh paket penyimpanan cloud.",tone:"tone-teal",symbol:"☁",featured:8}
];
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const money=n=>new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n);
const load=(k,f)=>{try{return JSON.parse(localStorage.getItem(k))??f}catch{return f}};
const state={cat:"Semua",query:"",sort:"featured",cart:load("bm_cart",[]),orders:load("bm_orders",[])};
const safe=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function persist(){try{localStorage.setItem("bm_cart",JSON.stringify(state.cart));localStorage.setItem("bm_orders",JSON.stringify(state.orders))}catch{toast("Penyimpanan browser tidak tersedia.")}}
function render(){
 let list=products.filter(p=>(state.cat==="Semua"||p.category===state.cat)&&`${p.name} ${p.category} ${p.description}`.toLowerCase().includes(state.query.toLowerCase()));
 if(state.sort==="low")list.sort((a,b)=>a.price-b.price);else if(state.sort==="high")list.sort((a,b)=>b.price-a.price);else if(state.sort==="name")list.sort((a,b)=>a.name.localeCompare(b.name));else list.sort((a,b)=>a.featured-b.featured);
 $("#resultCount").textContent=`${list.length} PRODUK`;
 $("#productGrid").innerHTML=list.map(p=>`<article class="product-card"><div class="product-art ${p.tone}" data-detail="${p.id}" role="button" tabindex="0" aria-label="Detail ${safe(p.name)}">${p.badge?`<span class="product-badge">${p.badge}</span>`:""}<span class="product-symbol">${p.symbol}</span></div><div class="product-info"><div class="product-meta"><span>${p.category}</span><span class="stock">Contoh</span></div><h3 title="${safe(p.name)}">${safe(p.name)}</h3><p>${safe(p.description)}</p><div class="product-bottom"><div class="price">${p.oldPrice?`<s>${money(p.oldPrice)}</s>`:""}${money(p.price)}</div><button class="add" data-add="${p.id}" aria-label="Tambah ${safe(p.name)}">+</button></div></div></article>`).join("");
 $("#empty").classList.toggle("hidden",list.length>0);$("#productGrid").classList.toggle("hidden",list.length===0);
}
function count(){return state.cart.reduce((s,i)=>s+i.qty,0)}function total(){return state.cart.reduce((s,i)=>s+products.find(p=>p.id===i.id).price*i.qty,0)}
function updateCount(){$("#cartCount").textContent=count();$("#itemsCount").textContent=count();$("#orderCount").textContent=state.orders.length}
function toast(msg){let el=$("#toast");el.textContent=msg;el.classList.add("show");clearTimeout(toast.t);toast.t=setTimeout(()=>el.classList.remove("show"),2600)}
function add(id){let item=state.cart.find(i=>i.id===id);if(item)item.qty++;else state.cart.push({id,qty:1});persist();updateCount();renderCart();toast("Produk ditambahkan ke keranjang.")}
function qty(id,n){let item=state.cart.find(i=>i.id===id);if(!item)return;item.qty+=n;if(item.qty<1)state.cart=state.cart.filter(i=>i.id!==id);persist();updateCount();renderCart()}
function renderCart(){
 if(!state.cart.length){$("#drawerContent").innerHTML=`<div class="cart-empty"><div>♧</div><h3>Keranjang masih kosong</h3><p>Pilih produk untuk melihat ringkasannya di sini.</p><button class="button primary" id="browse">Jelajahi produk ↗</button></div>`;$("#drawerFooter").innerHTML="";$("#browse")?.addEventListener("click",closeDrawer);return}
 $("#drawerContent").innerHTML=state.cart.map(i=>{let p=products.find(p=>p.id===i.id);return `<div class="cart-item"><div class="cart-thumb ${p.tone}">${p.symbol}</div><div><strong>${safe(p.name)}</strong><small>${money(p.price)} / item</small><div class="qty"><button data-qty="${p.id}" data-delta="-1">−</button><span>${i.qty}</span><button data-qty="${p.id}" data-delta="1">+</button><button class="remove" data-remove="${p.id}" aria-label="Hapus">×</button></div></div><div class="item-total">${money(p.price*i.qty)}</div></div>`}).join("");
 $("#drawerFooter").innerHTML=`<div class="total-row"><span>Subtotal (${count()} item)</span><strong>${money(total())}</strong></div><button class="button primary" id="askWhatsApp">Tanya admin via WhatsApp ↗</button><p>Harga contoh. Tidak ada pembayaran yang diproses di website ini.</p>`;$("#askWhatsApp").onclick=whatsAppCart;
}
function openDrawer(){$("#drawer").classList.add("open");$("#drawer").setAttribute("aria-hidden","false");$("#scrim").classList.remove("hidden");document.body.style.overflow="hidden";renderCart()}
function closeDrawer(){$("#drawer").classList.remove("open");$("#drawer").setAttribute("aria-hidden","true");$("#scrim").classList.add("hidden");document.body.style.overflow=""}
function modal(html){$("#modalContent").innerHTML=html;$("#backdrop").classList.remove("hidden");document.body.style.overflow="hidden"}
function closeModal(){$("#backdrop").classList.add("hidden");document.body.style.overflow=""}
function detail(id){let p=products.find(p=>p.id===id);if(!p)return;modal(`<div class="detail-art ${p.tone}"><span>${p.symbol}</span></div><div class="modal-category">${p.category} · ${p.id.toUpperCase()}</div><h2 id="modalTitle">${safe(p.name)}</h2><p>${safe(p.description)}</p><div class="detail-price">${money(p.price)}</div><div class="notice">Produk dan harga ini adalah data contoh. Konfirmasikan ketersediaan, lisensi, dan ketentuan kepada admin sebelum membeli.</div><div class="modal-actions"><button class="button outline" id="detailClose">Tutup</button><button class="button primary" id="detailAdd">＋ Tambah ke keranjang</button></div>`);$("#detailClose").onclick=closeModal;$("#detailAdd").onclick=()=>{closeModal();add(id)}}
function whatsAppCart(){if(!state.cart.length)return;const lines=state.cart.map(i=>{let p=products.find(p=>p.id===i.id);return `• ${p.name} x${i.qty} — ${money(p.price*i.qty)}`});let msg=`Halo admin BRIAN MARKET, saya ingin bertanya tentang produk berikut:\n${lines.join("\n")}\n\nSubtotal contoh: ${money(total())}\nMohon konfirmasi ketersediaan dan proses pemesanan.`;window.open(`https://wa.me/${ADMIN_WHATSAPP}?text=${encodeURIComponent(msg)}`,"_blank","noopener,noreferrer")}
function orders(){let body=state.orders.length?state.orders.map(o=>`<article class="order-card"><strong>${safe(o.id)} · ${safe(o.date)}</strong><p>${safe(o.items)}</p><footer>${o.count} item <b style="float:right">${money(o.total)}</b></footer></article>`).join(""):`<div class="cart-empty"><div>▤</div><h3>Belum ada pesanan demo</h3><p>Pesanan demo hanya disimpan di browser ini.</p></div>`;modal(`<div class="modal-category">AREA PENGGUNA</div><h2 id="modalTitle">Riwayat <em style="color:var(--purple)">demo.</em></h2><p>Ini bukan catatan transaksi server atau bukti pembayaran.</p>${body}<div class="modal-actions"><button class="button outline" id="ordersClose">Tutup</button>${state.cart.length?'<button class="button primary" id="createOrder">Buat catatan demo</button>':""}</div>`);$("#ordersClose").onclick=closeModal;$("#createOrder")?.addEventListener("click",createOrder)}
function createOrder(){let o={id:"DEMO-"+Date.now().toString().slice(-7),date:new Date().toLocaleDateString("id-ID"),items:state.cart.map(i=>`${products.find(p=>p.id===i.id).name} ×${i.qty}`).join(", "),count:count(),total:total()};state.orders.unshift(o);state.cart=[];persist();updateCount();renderCart();closeModal();toast("Catatan pesanan demo dibuat.");orders()}
$("#search").addEventListener("input",e=>{state.query=e.target.value;render()});$("#sort").addEventListener("change",e=>{state.sort=e.target.value;render()});
$("#filters").addEventListener("click",e=>{let b=e.target.closest("[data-cat]");if(!b)return;state.cat=b.dataset.cat;$$(".filter").forEach(x=>x.classList.toggle("active",x===b));render()});
$("#productGrid").addEventListener("click",e=>{let a=e.target.closest("[data-add]"),d=e.target.closest("[data-detail]");if(a)add(a.dataset.add);else if(d)detail(d.dataset.detail)});
$("#productGrid").addEventListener("keydown",e=>{if((e.key==="Enter"||e.key===" ")&&e.target.matches("[data-detail]")){e.preventDefault();detail(e.target.dataset.detail)}});
$("#reset").onclick=()=>{state.cat="Semua";state.query="";state.sort="featured";$("#search").value="";$("#sort").value="featured";$$(".filter").forEach(b=>b.classList.toggle("active",b.dataset.cat==="Semua"));render()};
$("#jumpSearch").onclick=()=>{$("#search").focus();$("#products").scrollIntoView({behavior:"smooth"})};
$("#openCart").onclick=openDrawer;$("#closeDrawer").onclick=closeDrawer;$("#scrim").onclick=closeDrawer;$("#drawerContent").addEventListener("click",e=>{let q=e.target.closest("[data-qty]"),r=e.target.closest("[data-remove]");if(q)qty(q.dataset.qty,Number(q.dataset.delta));if(r){state.cart=state.cart.filter(i=>i.id!==r.dataset.remove);persist();updateCount();renderCart()}});
$("#closeModal").onclick=closeModal;$("#backdrop").addEventListener("click",e=>{if(e.target===$("#backdrop"))closeModal()});$("#ordersBtn").onclick=orders;
$("#hamburger").onclick=()=>$("#nav").classList.toggle("open");$("#nav").addEventListener("click",e=>{if(e.target.closest("a"))$("#nav").classList.remove("open")});
$("#whatsapp").href=`https://wa.me/${ADMIN_WHATSAPP}?text=${encodeURIComponent("Halo admin BRIAN MARKET, saya ingin bertanya tentang produk digital.")}`;
document.addEventListener("keydown",e=>{if(e.key==="Escape"){closeModal();closeDrawer()}if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="k"){e.preventDefault();$("#search").focus();$("#products").scrollIntoView({behavior:"smooth"})}});
$("#year").textContent=new Date().getFullYear();render();renderCart();updateCount();
