# Backend integration plan (not connected yet)

This folder is a starting point for a future Supabase/PostgreSQL backend. Nothing in this folder is deployed or connected to the storefront.

## Suggested setup

1. Create a Supabase project.
2. Review and run `schema.sql` in the SQL editor.
3. Configure Auth providers and email confirmation.
4. Review all Row Level Security policies for your use case before production.
5. Use Supabase Edge Functions or a trusted server for order creation and payment operations.
6. Add only the public Supabase URL and anon/publishable key to frontend environment/config. Never expose a service-role key.
7. Add a payment gateway (for Indonesia, choose a provider suitable for your business and complete its onboarding). Keep secret keys server-side.
8. Implement a webhook endpoint that verifies the provider signature before marking an order paid.

## Important

The SQL is a starting schema, not a complete audited production system. It deliberately does not create an unrestricted admin role or payment workflow. Product fulfillment, account inventory, refund rules, legal compliance, and access policies must be designed and tested before going live.
