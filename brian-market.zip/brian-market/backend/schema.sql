-- BRIAN MARKET starter schema for Supabase/PostgreSQL.
-- Review before running. This file is NOT applied to any database.
create extension if not exists pgcrypto;

create type public.order_status as enum (
  'pending', 'awaiting_payment', 'paid', 'processing',
  'completed', 'cancelled', 'refunded'
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  slug text not null unique,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.categories(id) on delete set null,
  slug text not null unique,
  name text not null,
  description text not null default '',
  price_idr bigint not null check (price_idr >= 0),
  stock_quantity integer check (stock_quantity is null or stock_quantity >= 0),
  is_active boolean not null default false,
  image_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  order_number text not null unique,
  status public.order_status not null default 'pending',
  currency char(3) not null default 'IDR',
  subtotal_idr bigint not null check (subtotal_idr >= 0),
  discount_idr bigint not null default 0 check (discount_idr >= 0),
  total_idr bigint not null check (total_idr >= 0),
  customer_email text,
  customer_name text,
  payment_provider text,
  payment_reference text,
  paid_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (total_idr = subtotal_idr - discount_idr)
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name_snapshot text not null,
  unit_price_idr bigint not null check (unit_price_idr >= 0),
  quantity integer not null check (quantity > 0),
  line_total_idr bigint not null check (line_total_idr = unit_price_idr * quantity)
);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null,
  display_name text not null,
  rating integer not null check (rating between 1 and 5),
  body text not null check (char_length(body) between 1 and 2000),
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);

-- Enable RLS. Policies should be tested and tightened before public use.
alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.reviews enable row level security;

-- Public can read active catalog and published reviews only.
create policy "Public reads active categories" on public.categories
  for select using (is_active = true);
create policy "Public reads active products" on public.products
  for select using (is_active = true);
create policy "Public reads published reviews" on public.reviews
  for select using (is_published = true);

-- Authenticated users can read/update only their own profile.
create policy "Users read own profile" on public.profiles
  for select to authenticated using (auth.uid() = id);
create policy "Users update own profile" on public.profiles
  for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- Orders are intentionally not directly insertable/updateable by client policies.
-- Use a trusted server/Edge Function to validate prices and create order rows.
-- Add an audited admin role and server-only management operations separately.
